import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        Thread t1 = new Thread(() -> {
            System.out.println("yo");
            int t = 0;
            while (true) {
                t++;

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (t == 14) {
                    // System.out.println("laikas baiges!");
                    break;
                }
            }
        });
        Thread t2 = new Thread(() -> {
            System.out.println("susumuok!");
            int a;
            int b;
            int spejimai = 0;
            int teisingiSpejimai = 0;

            while (true) {
                a = randomasIki99();
                b = randomasIki99();
                System.out.print(a + " + " + b + " = ");
                Scanner sc = new Scanner(System.in);
                int ats = sc.nextInt();
                if (ats == (a + b)) {
                    System.out.println("pasiseke");
                    teisingiSpejimai++;
                    spejimai++;
                } else {
                    System.out.println("feilas!");
                    spejimai++;
                }
                if (!t1.isAlive()) {
                    System.out.println("laikas baiges!");
                    System.out.println("teisingu atsakymu " + teisingiSpejimai + " is " + spejimai);
                    break;
                }
            }
        });

        t1.start();
        t2.start();
    }

    static int randomasIki99() {
        Random rnd = new Random();
        int randomInt = rnd.nextInt(10);
        return randomInt;
    }
}

